const form = document.getElementById("registrationForm").addEventListener()
function submit(){
    let nome = document.getElementById("nomeUtente").value.trim();
    let email = document.document.getElementById("email").value.trim()
    let data = document.getElementById("data").value;
    let ora = document.getElementById("ora").value;
    let messaggio = document.getElementById().value.trim();
    let opzione = document.getElementById().checked;

    let riepilogo = "<h1>Riepilo del Feedback</h1><h2>Nome:"+nome+"</h2><h2>Email:"+email+"</h2><h2>Data:"+data+"</h2><h2>Ora:"+ora+"</h2><h2>Messaggio:"+messaggio+"</h2> <h2>Iscrizione alla newsletter:"+opzione+"</h2>";
    document.getElementById("riepilogo").innerHTML=riepilogo;
}
